<?php

@include 'config.php';

if(isset($_POST['seConnecter'])){
   $nom = $_POST['nom'];
   $password = $_POST['password'];
   

  // $insert_query = mysqli_query ($conn, "INSERT INTO `usertable`(nom, password) VALUES('$nom', '$password')") or die('query failed');
  $insert_query = mysqli_query ($conn, "SELECT * FROM usertable WHERE nom=$nom && password=$password") ;
   if($insert_query){
     header("location: http://localhost/shopping%20cart/PROJET%20DEV%20WEB/apres%20connexion/home.php");
   }else{
      echo '<script> alert("Nom ou mot de passe invalide");</script>';
   }
};

?>


<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>S'inscrire</title>
<link rel="stylesheet" type="text/css" href="style.css">
	<link href="https://fonts.googleapis.com/css2?family=Josefin+Sans:ital,wght@0,400;0,700;1,500&display=swap" rel="stylesheet">
	<link rel="icon" type="image/x-icon" href="logo.png">
</head>
<body>
<?php include 'header.php'; ?>
	
	<br><br><br>
    <section class="inscription">
		<form action="" method="post">
			<h1>Connectez-vous</h1>
			<input type="text" placeholder="Nom d'utilisateur" name="nom">
			<br/>
			<input type="password" name="password" id="" placeholder="Mot de passe" style="margin-top: 7px;">
			<br><br>
			<input type="submit" id="seConnecter" value="Se connecter" name="seConnecter"><br>
			<br><p>Vous n'avez pas de compte? <a href="S'inscrire.php">S'inscrire</a></p>
		</form>
	</section>
	<script src="projet.js"></script>
</body>
</html>