<link href="https://fonts.googleapis.com/css2?family=Josefin+Sans:ital,wght@0,400;0,700;1,500&display=swap" rel="stylesheet">

            <section class="entete">
            <a href="home.php" class="logo">
                <img src="logo.png" class="logo"" >
            </a>
            <a href="products.php" class="infos">Menu</a>
            <a href="home.php" class="infos">ABOUT US</a>
            <a href="Se connecter.php" class="infos">Se Connecter</a>
            <a href="S'inscrire.php" class="infos">S'inscrire</a>
           
        </section>
<header class="header">




   <div class="flex">

      <a href="#" class="logo"></a>

      <nav class="navbar">
         <a href="admin.php">Make your Burger</a>
         <a href="products.php">Menu</a>
      </nav>

      <?php
      
      $select_rows = mysqli_query($conn, "SELECT * FROM `cart`") or die('query failed');
      $row_count = mysqli_num_rows($select_rows);

      ?>

      <a href="cart.php" class="cart">cart <span><?php echo $row_count; ?></span> </a>

   

   </div>

</header>