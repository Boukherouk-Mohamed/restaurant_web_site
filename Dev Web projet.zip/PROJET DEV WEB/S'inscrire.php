<?php

@include 'config.php';

if(isset($_POST['create'])){

   $nom = $_POST['nom'];
   $prenom = $_POST['prenom'];
   $email = $_POST['email'];
   $password = $_POST['password'];
   

   $insert_query = mysqli_query ($conn, "INSERT INTO `inscription`(nom,prenom,email,password) VALUES('$nom','$prenom' ,'$email ', '$password')") ;
   $insert_query = mysqli_query ($conn, " INSERT INTO `usertable`(nom,password) VALUES('$nom','$password')") ;
   if($insert_query){
     header("location: apres connexion/home.php");
   }else{
      echo '<script> alert("Probleme d inscription, veuillez ressayez.");</script>';
   }
};
?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>S'inscrire</title>
<link rel="stylesheet" type="text/css" href="style.css">
	<link href="https://fonts.googleapis.com/css2?family=Josefin+Sans:ital,wght@0,400;0,700;1,500&display=swap" rel="stylesheet">
	<link rel="icon" type="image/x-icon" href="logo.png">
</head>
<body>
	
<?php include 'header.php'; ?>

   <br><br><br> <section class="inscription">
		<form action="" method="post">
			<h1>Connectez-vous</h1>
			<input type="text" placeholder="nom" name="nom" required>
			<input type="text" placeholder="prenom" name="prenom" style="margin-top: 7px;"  required>
			<input type="text" placeholder="email" name="email" style="margin-top: 7px;"  required>
			<input type="password" placeholder="password" name="password" style="margin-top: 7px;"  required> <br><br>
			
			
			<input type="submit" id="seConnecter" name="create" value="S'inscrire">
			<br><br><p>Vous avez déja un compte? <a href="Se connecter.php">Se connecter</a></p>
		</form>
	</section>
	<script src="projet.js"></script>
</body>
</html>