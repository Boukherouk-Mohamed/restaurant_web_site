<?php

@include 'config.php';

if(isset($_POST['order_btn'])){

   $name = $_POST['name'];
   $number = $_POST['number'];
   $email = $_POST['email'];
   $adresse = $_POST['adresse'];


   $cart_query = mysqli_query($conn, "SELECT * FROM `cart`");
   $price_total = 0;
   if(mysqli_num_rows($cart_query) > 0){
      while($product_item = mysqli_fetch_assoc($cart_query)){
         $product_name[] = $product_item['name'] .' ('. $product_item['quantity'] .') ';
         $product_price = number_format($product_item['price'] * $product_item['quantity']);
         $price_total += $product_price;
      };
   };

   $total_product = implode(', ',$product_name);
   $detail_query = mysqli_query($conn, "INSERT INTO `order`(name, number, email, adresse, total_products, total_price) VALUES('$name','$number','$email','$adresse','$total_product','$price_total')") ;

   if($cart_query && $detail_query){
      echo "
      <div class='order-message-container'>
      <div class='message-container'>
         <h3>Merci de nous choisir!</h3>
         <div class='order-detail'>
         
            <span class='total'> total : ".$price_total." DH  </span>
         </div>
         <div class='customer-details'>
            
         <p>  Votre commande est passee! </p>
           
            <p style='color:red;'>(payement à l'arrivée de la commande.)</p>
         </div>
            <a href='products.php' class='btn'>Retour au menu</a>
         </div>
      </div>
      ";
   }

}

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>checkout</title>

   <link rel="stylesheet" href="style.css">

</head>
<body>

<?php include 'header.php'; ?>

<div class="container">

<section class="checkout-form">

   <h1 class="heading">Commander</h1>

   <form action="" method="post">

   <div class="display-order">
      <?php
         $select_cart = mysqli_query($conn, "SELECT * FROM `cart`");
         $total = 0;
         $grand_total = 0;
         if(mysqli_num_rows($select_cart) > 0){
            while($fetch_cart = mysqli_fetch_assoc($select_cart)){
            $total_price = number_format($fetch_cart['price'] * $fetch_cart['quantity']);
            $grand_total = $total += $total_price;
      ?>
      <span><?= $fetch_cart['name']; ?>(<?= $fetch_cart['quantity']; ?>)</span>
      <?php
         }
      }else{
         echo "<div class='display-order'><span>your cart is empty!</span></div>";
      }
      ?>
      <span class="grand-total"> A Payer : <?= $grand_total; ?> DH </span>
   </div>

      <div class="flex">
         <div class="inputBox">
            <span>Nom</span>
            <input type="text" placeholder="entrer votre nom" name="name" required>
         </div>
         <div class="inputBox">
            <span>Num Tel</span>
            <input type="number" placeholder="entrer votre num de tel" name="number" required>
         </div>
         <div class="inputBox">
            <span>email</span>
            <input type="email" placeholder="entrer votre email" name="email" required>
         </div>
         
        
         <div class="inputBox">
            <span>Adresse</span>
            <input type="text" placeholder="Adresse" name="adresse" required>
         </div>
         
      </div>
      <input type="submit" value="Commander" name="order_btn" class="btn">
   </form>

</section>

</div>


<script src="js/script.js"></script>
   
</body>
</html>