<?php

@include 'config.php';
$ingredients = array();
$ingredients[0] = "Pas de Salade";
$ingredients[1] = "Pas de Bacon";
$ingredients[2] = "Pas de Fromage";
$ingredients[3] = "Pas de Kefta";

if(isset($_POST['addSalade'])){
   $ingredients[0]="Plus de Salade";
};
if(isset($_POST['removeSalade'])){
   $ingredients[0]="Pas de Salade";
};

if(isset($_POST['addBacon'])){
   $ingredients[1]="Plus de Bacon";
};
if(isset($_POST['removeBacon'])){
   $ingredients[1]="Pas de Bacon";
};

if(isset($_POST['addChaise'])){
   $ingredients[2]="Plus de Chaise";
};
if(isset($_POST['removeChaise'])){
   $ingredients[2]="Pas de Chaise";
};

if(isset($_POST['addKefta'])){
   $ingredients[3]="Plus de Kefta";
};
if(isset($_POST['removeKefta'])){
   $ingredients[3]="Pas de Kefta";
};

if(isset($_POST['demander'])){
   $serialized_ingredients  = serialize($ingredients);
   
   $insert_query = mysqli_query($conn, "INSERT INTO `burger`(ingredient) VALUES('$serialized_ingredients'); ");
   echo '<script> alert("Votre Demande est ajoutee"); </script>';
};



?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>admin panel</title>


   <link rel="stylesheet" href="style.css">

</head>
<body>
   


<?php include 'header.php'; ?>


<section>

<div class="but">
   <form action="" method="post">

            <font class="salade">Salade :  </font>
            <input type="submit" class="but1" onclick="myfct(0)" value="+" name="addSalade"></input>
            <input type="submit" class="but1" onclick="myfct1(0)" value="-" name="removeSalade"></input>
            
            <font class="salade">Bacon :  </font>
            <input type="submit" class="but1" onclick="myfct(1)" value="+" name="addBacon"></input>
            <input type="submit"  class="but1" onclick="myfct1(1)" value="-" name="removeBacon"></input>
            <font class="salade">Chaise :  </font>
            <input type="submit" class="but1" onclick="myfct(2)" value="+" name="addChaise"></input>
            <input type="submit"  class="but1" onclick="myfct1(2)" value="-" name="removeChaise"></input>
            <font class="salade">Kefta :  </font>
            <input type="submit" class="but1" onclick="myfct(3)" value="+" name="addKefta"></input>
            <input type="submit"  class="but1" onclick="myfct1(3)" value="-" name="removeKefta"></input>
        
   </form>
            </div>
        <div class="burg"> <br><br><br>
            <div id="1">
            <div class="elemnts">    
            
            <div id="d0" style="height: 80px"></div>
           
            
            <div  id="d11" class="d1" style="height: 30px"></div> 
            <div id="d2" class="d1" style="height: 30px"></div>
            <div id="d3" class="d1" style="height: 30px"></div>
            <div id="d4" class="d1" style="height: 30px"></div>
            <div id="breod-buttom" style="height: 80px"></div>
        </div>

</section>
<form action="" method="post">

   <input type="submit" value="Demander" name="demander" class="but1" style="background-color: red; height: 35px; width:120px;text-align: center;font-size: 22px; display:flex; margin-left: auto; margin-right:auto">
</form>













<script src="script.js"></script>

</body>
</html>