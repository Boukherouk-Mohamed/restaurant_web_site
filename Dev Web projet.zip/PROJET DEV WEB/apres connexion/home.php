<?php

@include 'config.php';

?>


<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>HOME</title>
	<link rel="stylesheet" type="text/css" href="style.css">
	 <link href="https://fonts.googleapis.com/css2?family=Josefin+Sans:ital,wght@0,400;0,700;1,500&display=swap" rel="stylesheet">
	<link rel="icon" type="image/x-icon" href="logo.png">
</head>
<body>
<?php include 'header - 2.php'; ?>
	
			
			<section >
				<div class="container2">
					<div class="box1">
						<p class="commande_text" >WELCOME TO NBO RESTAURANT</p>
					</div>
					<div class="box2">
						<h1 style="color:rgb(94, 86, 86)">Bienvenue :</h1>
						<br><p>Ce site est un prototype d'une site de restauration, vous pouvez commander en ligne ainsi que vous pouvez réserver une table pour n'importe quel jour!</p><br>
						<a href="reserver.php"><button class="reserver">RESERVER UNE TABLE</button></a> 
						<br>
						<a href="products.php"><button class="commander">COMMANDER EN LIGNE</button></a>  
						<br>
					</div>
				</div>
				
			</section>
			</section>
			

			
	</section><hr>
	<br>
	<section class="about_us" id="about_us">
				<div style="margin-top: 30px;" > <hr>
					<h1 class="titre">ABOUT US :</h1> 
					<br><br><p class="p_about_us">Ce site est un prototype d'une site de restauration, vous pouvez commander en ligne ainsi que vous pouvez réserver une table pour n'importe quel jour!</p>
				</div><br>

	</section>


	<section class="follow">
	<hr><div>
			<p style="font-size: 30px;font-family: 'Josefin Sans', sans-serif;">follow us</p>
			<a href=""><img src="insta.png" class="insta"></a>
			<a href=""><img src="linkedin.png" class="linkedin"></a>
			<a href="">	<img src="fb.png" class="fb"></a>
			<a href=""><img src="ytb.png" class="ytb"></a>
			
		
			
		</div>
		
	</section>


	<script src=""></script>
</body>
</html>