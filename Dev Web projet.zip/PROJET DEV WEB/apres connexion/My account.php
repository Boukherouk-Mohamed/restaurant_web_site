<?php

@include 'config.php';
?>


<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>My Account</title>
   <link rel="stylesheet" href="style.css">
</head>
<body>
<?php include 'header - 2.php'; ?><br><br><br><br><br>
<div class="account" style="   padding: 2rem;
   margin-right: auto;
   margin-left: auto;
   width: 80%;
  height: auto;
   background-color: #cec7c7;
   border-radius: 25px;">
        <h1  style="text-align: center; font-size: 35px;">My Account</h1><hr>
       <br> <br><br>
       <div class="infos_user" style="   display: flex;">
            <div class="infos_user_1" style="   margin-right: auto; display: grid;gap: 2rem;font-size: 22px;">
                <div class="nom_user">
                    <p>Nom : <?php  $select_name = mysqli_query($conn, "SELECT * FROM `inscription` ");
                    $fetch_product = mysqli_fetch_assoc($select_name);
                    echo $fetch_product['nom'];   ?>  </p>
                </div>
                <div class="email_user">
                    <p> Email : <?php  $select_name = mysqli_query($conn, "SELECT * FROM `inscription` ");
                    $fetch_product = mysqli_fetch_assoc($select_name);
                    echo $fetch_product['email'];   ?>   </p>
                </div>
                <div class="prenom_user">
                    <p>Prenom : <?php  $select_name = mysqli_query($conn, "SELECT * FROM `inscription` ");
                    $fetch_product = mysqli_fetch_assoc($select_name);
                    echo $fetch_product['prenom'];   ?></p>
                </div>
                <div class="password">
                    <p>Password : <?php  $select_name = mysqli_query($conn, "SELECT * FROM `inscription` ");
                    $fetch_product = mysqli_fetch_assoc($select_name);
                    echo $fetch_product['password'];   ?></p>
                </div><br>
            </div>
        <div class="import_image" style="   border: 1px solid black;
   border-radius: 25px;
   margin-left: auto;
   height: 10px;
   width: 40%;
   height: 140px;
  overflow: hidden;">
            <p style="font-size: 22px; text-align: center;">Image :</p><br><br><br>
            <input type="file" name="image_user" id="" value="Choisir une image">
        </div>
           
       </div>
        
    </div>
    
</body>
</html>