<?php

$conn = mysqli_connect('localhost','root','','projet_web') or die('connection failed');

?>