<?php

@include 'config.php';

?>


<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>S'inscrire</title>
<link rel="stylesheet" type="text/css" href="style.css">
	<link href="https://fonts.googleapis.com/css2?family=Josefin+Sans:ital,wght@0,400;0,700;1,500&display=swap" rel="stylesheet">
	<link rel="icon" type="image/x-icon" href="logo.png">
</head>
<body>
<?php include 'header.php'; ?>
	
	<br><br><br>
    <section class="inscription">
		<form action="" method="post">
			<h1>Connectez-vous</h1>
			<input type="text" placeholder="Nom d'utilisateur" name="nom">
			<br/>
			<input type="password" name="password" id="" placeholder="Mot de passe" style="margin-top: 7px;">
			<br><br>
			<input type="submit" id="seConnecter" value="Se connecter"><br>
			<br><p>Vous n'avez pas de compte? <a href="S'inscrire.php">S'inscrire</a></p>
		</form>
	</section>
	<script src="projet.js"></script>
</body>
</html>