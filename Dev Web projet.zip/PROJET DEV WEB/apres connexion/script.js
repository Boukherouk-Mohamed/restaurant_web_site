let menu = document.querySelector('#menu-btn');
let navbar = document.querySelector('.header .navbar');

menu.onclick = () =>{
   menu.classList.toggle('fa-times');
   navbar.classList.toggle('active');
};

window.onscroll = () =>{
   menu.classList.remove('fa-times');
   navbar.classList.remove('active');
};


document.querySelector('#close-edit').onclick = () =>{
   document.querySelector('.edit-form-container').style.display = 'none';
   window.location.href = 'admin.php';
};




const x=document.querySelectorAll(".d1");
for(let i=0;i<x.length;i++){
x[i].style.display="inline";}
for(let i=0;i < x.length;i++){
function myfct(i) {
    x[i].style.display = "block";  
}
}
for(let i=0;i < x.length;i++){
  function myfct1(i) {
  
      x[i].style.display = "none";
    
  }
}
