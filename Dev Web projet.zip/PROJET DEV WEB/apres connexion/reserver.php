
<?php

@include 'config.php';

if(isset($_POST['submit'])){

    $nom = $_POST['nom'];
    $prenom = $_POST['prenom'];
    $tel = $_POST['tel'];
    $email = $_POST['email'];
    $plat = $_POST['plat'];
    $number = $_POST['number'];
    $date = $_POST['date'];

   $select_cart = mysqli_query($conn, "SELECT * FROM `reservation` WHERE nom = '$nom' && plat = '$plat'");

   if(mysqli_num_rows($select_cart) > 0){
    echo '<script> alert("demande deja faites");</script>';
      //$message[] = 'Demande déja faite';
   }else{
      $insert_product = mysqli_query($conn, "INSERT INTO `reservation`(nom,prenom,tel,email,plat,number,date) VALUES('$nom','$prenom','$tel','$email','$plat','$number','$date')");
     // $message[] = 'Demande ajouté .';
     echo '<script> alert("reservation bien ajouté");</script>';
   }

}

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>RESERVER</title>
    <link rel="stylesheet" href="style.css">
</head>
<body style="background: #fff;">
<?php include 'header - 2.php'; ?><hr><br><br><br>
    
    <section class="reservation">
        <div >
            
            <form action="" method="post">
                <input type="text" placeholder="Nom" name="nom" class="inputReservation" >
                <input type="text" placeholder="Prenom" name="prenom" class="inputReservation">
                <input type="text" placeholder="Num Tel" name="tel" class="inputReservation">
                <input type="email" placeholder="Email" name="email" class="inputReservation"><br>
                <input type="date" name="date" class="dateReserv" >
                <input type="text" placeholder="Plat demandé" name="plat" class="inputReservation"><br>
                <br> <span style="font-size: 18px;">Nombre de personne : </span>  <input type="number" name="number" value="1" class="numberPers">
                <input type="submit" name="submit" value="Reserver" class="inputReservation">
               
            

            </form>
            
    </section> 
    
   <br><br><br> <section class="follow">
		<div><hr>
			<p style="font-size: 30px;font-family: 'Josefin Sans', sans-serif;">follow us</p>
			<a href=""><img src="insta.png" class="insta"></a>
			<a href=""><img src="linkedin.png" class="linkedin"></a>
			<a href="">	<img src="fb.png" class="fb"></a>
			<a href=""><img src="ytb.png" class="ytb"></a>
			
		
			
		</div>
		
	</section>
	
	<script src="projet.js"></script>
</body>
</html>